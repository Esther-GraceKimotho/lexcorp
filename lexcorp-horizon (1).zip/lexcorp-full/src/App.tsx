import { useState } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { Login } from './components/Login';
import { Toaster } from 'sonner';
import { useAppContext } from './context/AppContext';

// Portal Shell Wrappers (Strict isolated containers)
import { AdvocatePortal } from './components/portals/AdvocatePortal';
import { HRPortal } from './components/portals/HRPortal';
import { ProcurementPortal } from './components/portals/ProcurementPortal';
import { Shield } from 'lucide-react';

export default function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const { user, role, isLoading, logout } = useAppContext();

  if (isLoading) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-brand-navy-base">
        <div className="flex flex-col items-center gap-3">
          <Shield className="h-10 w-10 text-brand-gold animate-pulse" />
          <span className="text-sm font-semibold tracking-widest text-brand-gold font-mono uppercase">Syncing Security Credentials...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <Login />
        <Toaster theme="dark" position="bottom-right" richColors />
      </>
    );
  }

  return (
    <Router>
      <div className="relative w-full h-screen overflow-hidden">
        {/* Hard Switch Root Layout Controller: Complete Omit, Unmount and Denial of Other Portals */}
        {role === 'Advocate' && (
          <AdvocatePortal 
            onLogout={logout} 
            isMobileMenuOpen={isMobileMenuOpen} 
            setIsMobileMenuOpen={setIsMobileMenuOpen} 
          />
        )}

        {role === 'HR_Manager' && (
          <HRPortal 
            onLogout={logout} 
            isMobileMenuOpen={isMobileMenuOpen} 
            setIsMobileMenuOpen={setIsMobileMenuOpen} 
          />
        )}

        {role === 'Ops_Procurement' && (
          <ProcurementPortal 
            onLogout={logout} 
            isMobileMenuOpen={isMobileMenuOpen} 
            setIsMobileMenuOpen={setIsMobileMenuOpen} 
          />
        )}
      </div>
      <Toaster theme="dark" position="bottom-right" richColors />
    </Router>
  );
}
