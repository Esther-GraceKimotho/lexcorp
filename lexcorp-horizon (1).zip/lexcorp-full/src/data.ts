import { Client, TeamMember } from './types';

export const initialClients: Client[] = [
  {
    id: '1',
    name: 'Safaricom PLC',
    brsReg: 'PVT-YK12345',
    kraPin: 'P051234567Z',
    regDate: '2010-04-12',
    leadDirector: 'Peter Ndegwa',
    riskLevel: 'COMPLIANT',
    statusBRS: 'Green',
    statusKRA: 'Green',
    statusNSSF: 'Green',
    statusETIMS: 'Green',
  },
  {
    id: '2',
    name: 'Equity Group Holdings',
    brsReg: 'PUBL-44556',
    kraPin: 'P059876543A',
    regDate: '2005-08-22',
    leadDirector: 'James Mwangi',
    riskLevel: 'PENDING AUDIT',
    statusBRS: 'Green',
    statusKRA: 'Yellow',
    statusNSSF: 'Green',
    statusETIMS: 'Yellow',
  },
  {
    id: '3',
    name: 'Rift Valley Maize Millers',
    brsReg: 'PVT-MM8899',
    kraPin: 'P053322114B',
    regDate: '2018-11-05',
    leadDirector: 'John Kiprono',
    riskLevel: 'STRIKE-OFF RISK (SEC 894)',
    statusBRS: 'Red',
    statusKRA: 'Red',
    statusNSSF: 'Yellow',
    statusETIMS: 'Red',
  },
  {
    id: '4',
    name: 'Nairobi Tech Hub',
    brsReg: 'PVT-NH7721',
    kraPin: 'P054455667C',
    regDate: '2021-02-14',
    leadDirector: 'Jane Doe',
    riskLevel: 'TCC EMBARGO',
    statusBRS: 'Green',
    statusKRA: 'Red',
    statusNSSF: 'Yellow',
    statusETIMS: 'Green',
  }
];

export const initialTeam: TeamMember[] = [
  { id: '1', name: 'Alice Wanjiku', email: 'alice@firm.co.ke', role: 'Managing Partner' },
  { id: '2', name: 'Brian Omondi', email: 'brian@firm.co.ke', role: 'Associate' },
  { id: '3', name: 'David Mutua', email: 'david@firm.co.ke', role: 'Clerk' },
];
