export type RealisticRiskLevel = 'STRIKE-OFF RISK (SEC 894)' | 'eTIMS NON-COMPLIANT' | 'TCC EMBARGO' | 'COMPLIANT' | 'PENDING AUDIT' | 'High' | 'Medium' | 'Low';
export type ComplianceStatus = 'Green' | 'Yellow' | 'Red';

export interface Client {
  id: string;
  name: string;
  brsReg: string;
  kraPin: string;
  regDate: string;
  leadDirector: string;
  riskLevel: RealisticRiskLevel;
  statusBRS: ComplianceStatus;
  statusKRA: ComplianceStatus;
  statusNSSF: ComplianceStatus;
  statusETIMS: ComplianceStatus;
  branch_id?: string;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'Managing Partner' | 'Associate' | 'Clerk';
}
