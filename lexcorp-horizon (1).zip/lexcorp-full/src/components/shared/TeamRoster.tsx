import { Mail } from 'lucide-react';
import type { TeamMember } from '../../types';

export function TeamRoster({ team }: { team: TeamMember[] }) {
  return (
    <div className="overflow-x-auto rounded-lg border border-brand-navy-border bg-brand-navy-surface">
      <table className="w-full min-w-[480px] text-left text-sm">
        <thead>
          <tr className="border-b border-brand-navy-border text-xs tracking-wide text-slate-500">
            <th className="px-4 py-3 font-medium">Name</th>
            <th className="px-4 py-3 font-medium">Role</th>
            <th className="px-4 py-3 font-medium">Email</th>
          </tr>
        </thead>
        <tbody>
          {team.map((member) => (
            <tr
              key={member.id}
              className="border-b border-brand-navy-border/50 last:border-0 hover:bg-brand-navy-elevated/50"
            >
              <td className="px-4 py-3 font-medium text-slate-100">{member.name}</td>
              <td className="px-4 py-3 text-slate-300">{member.role}</td>
              <td className="px-4 py-3 text-slate-400">
                <a
                  href={`mailto:${member.email}`}
                  className="inline-flex items-center gap-1.5 hover:text-brand-gold"
                >
                  <Mail className="h-3.5 w-3.5" />
                  {member.email}
                </a>
              </td>
            </tr>
          ))}
          {team.length === 0 && (
            <tr>
              <td colSpan={3} className="px-4 py-8 text-center text-sm text-slate-500">
                No staff on record.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
