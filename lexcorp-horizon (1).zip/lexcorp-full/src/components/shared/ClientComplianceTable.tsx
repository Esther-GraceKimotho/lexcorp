import { useMemo, useState } from 'react';
import { Search, Download } from 'lucide-react';
import jsPDF from 'jspdf';
import type { Client } from '../../types';
import { StatusDot } from './StatusDot';
import { RiskBadge } from './RiskBadge';

interface ClientComplianceTableProps {
  clients: Client[];
  title: string;
  exportFileName?: string;
}

export function ClientComplianceTable({
  clients,
  title,
  exportFileName = 'compliance-report',
}: ClientComplianceTableProps) {
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return clients;
    return clients.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.brsReg.toLowerCase().includes(q) ||
        c.kraPin.toLowerCase().includes(q) ||
        c.leadDirector.toLowerCase().includes(q)
    );
  }, [clients, query]);

  const handleExport = () => {
    const doc = new jsPDF();
    doc.setFontSize(14);
    doc.text(title, 14, 16);
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text(new Date().toLocaleDateString(), 14, 22);

    let y = 32;
    doc.setFontSize(9);
    doc.setTextColor(0);
    doc.text('Entity', 14, y);
    doc.text('BRS Reg', 78, y);
    doc.text('KRA PIN', 116, y);
    doc.text('Risk', 158, y);
    y += 4;
    doc.setDrawColor(200);
    doc.line(14, y, 196, y);
    y += 5;

    filtered.forEach((c) => {
      if (y > 280) {
        doc.addPage();
        y = 20;
      }
      doc.text(c.name.slice(0, 34), 14, y);
      doc.text(c.brsReg, 78, y);
      doc.text(c.kraPin, 116, y);
      doc.text(c.riskLevel.slice(0, 24), 158, y);
      y += 7;
    });

    doc.save(`${exportFileName}.pdf`);
  };

  return (
    <div className="rounded-lg border border-brand-navy-border bg-brand-navy-surface">
      <div className="flex flex-col gap-3 border-b border-brand-navy-border p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search entity, BRS, KRA PIN, director..."
            className="w-full rounded-md border border-brand-navy-border bg-brand-navy-elevated py-2 pl-9 pr-3 text-sm text-slate-100 placeholder:text-slate-600 focus:border-brand-gold focus:outline-none"
          />
        </div>
        <button
          onClick={handleExport}
          className="flex items-center justify-center gap-2 rounded-md border border-brand-navy-border px-3 py-2 text-sm text-slate-300 transition hover:border-brand-gold hover:text-brand-gold"
        >
          <Download className="h-4 w-4" />
          Export PDF
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead>
            <tr className="border-b border-brand-navy-border text-xs tracking-wide text-slate-500">
              <th className="px-4 py-3 font-medium">Entity</th>
              <th className="px-4 py-3 font-medium">BRS Reg</th>
              <th className="px-4 py-3 font-medium">KRA PIN</th>
              <th className="px-4 py-3 font-medium">Lead Director</th>
              <th className="px-4 py-3 font-medium">Risk</th>
              <th className="px-4 py-3 text-center font-medium">BRS</th>
              <th className="px-4 py-3 text-center font-medium">KRA</th>
              <th className="px-4 py-3 text-center font-medium">NSSF</th>
              <th className="px-4 py-3 text-center font-medium">eTIMS</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((c) => (
              <tr
                key={c.id}
                className="border-b border-brand-navy-border/50 last:border-0 hover:bg-brand-navy-elevated/50"
              >
                <td className="px-4 py-3 font-medium text-slate-100">{c.name}</td>
                <td className="px-4 py-3 font-mono text-xs text-slate-400">{c.brsReg}</td>
                <td className="px-4 py-3 font-mono text-xs text-slate-400">{c.kraPin}</td>
                <td className="px-4 py-3 text-slate-300">{c.leadDirector}</td>
                <td className="px-4 py-3">
                  <RiskBadge level={c.riskLevel} />
                </td>
                <td className="px-4 py-3 text-center">
                  <StatusDot status={c.statusBRS} />
                </td>
                <td className="px-4 py-3 text-center">
                  <StatusDot status={c.statusKRA} />
                </td>
                <td className="px-4 py-3 text-center">
                  <StatusDot status={c.statusNSSF} />
                </td>
                <td className="px-4 py-3 text-center">
                  <StatusDot status={c.statusETIMS} />
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={9} className="px-4 py-8 text-center text-sm text-slate-500">
                  No entities match &quot;{query}&quot;.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
