import { ReactNode } from 'react';

interface StatCardProps {
  label: string;
  value: string | number;
  icon: ReactNode;
  tone?: 'default' | 'warn' | 'danger';
}

const TONE_CLASS: Record<NonNullable<StatCardProps['tone']>, string> = {
  default: 'text-brand-gold',
  warn: 'text-amber-400',
  danger: 'text-red-400',
};

export function StatCard({ label, value, icon, tone = 'default' }: StatCardProps) {
  return (
    <div className="rounded-lg border border-brand-navy-border bg-brand-navy-surface p-5">
      <div className="flex items-center justify-between">
        <p className="text-xs tracking-wide text-slate-500">{label}</p>
        <div className={TONE_CLASS[tone]}>{icon}</div>
      </div>
      <p className="mt-2 text-2xl font-semibold text-slate-100">{value}</p>
    </div>
  );
}
