import type { RealisticRiskLevel } from '../../types';

const STYLE_MAP: Record<RealisticRiskLevel, string> = {
  'COMPLIANT': 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400',
  'PENDING AUDIT': 'border-amber-500/30 bg-amber-500/10 text-amber-400',
  'TCC EMBARGO': 'border-orange-500/30 bg-orange-500/10 text-orange-400',
  'STRIKE-OFF RISK (SEC 894)': 'border-red-500/30 bg-red-500/10 text-red-400',
  'eTIMS NON-COMPLIANT': 'border-red-500/30 bg-red-500/10 text-red-400',
  High: 'border-red-500/30 bg-red-500/10 text-red-400',
  Medium: 'border-amber-500/30 bg-amber-500/10 text-amber-400',
  Low: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400',
};

export function RiskBadge({ level }: { level: RealisticRiskLevel }) {
  return (
    <span
      className={`inline-flex items-center whitespace-nowrap rounded-full border px-2.5 py-0.5 text-xs font-medium ${STYLE_MAP[level]}`}
    >
      {level}
    </span>
  );
}
