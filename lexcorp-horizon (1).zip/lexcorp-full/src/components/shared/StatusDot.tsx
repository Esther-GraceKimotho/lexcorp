import type { ComplianceStatus } from '../../types';

const COLOR_MAP: Record<ComplianceStatus, string> = {
  Green: '#22C55E',
  Yellow: '#EAB308',
  Red: '#EF4444',
};

export function StatusDot({ status }: { status: ComplianceStatus }) {
  return (
    <span
      className="status-dot"
      style={{ color: COLOR_MAP[status] }}
      title={status}
      aria-label={status}
    />
  );
}
