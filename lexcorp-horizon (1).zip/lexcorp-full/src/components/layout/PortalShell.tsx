import { ReactNode } from 'react';
import { LogOut, Menu, X, Shield } from 'lucide-react';

export interface NavItem {
  key: string;
  label: string;
  icon: ReactNode;
}

interface PortalShellProps {
  portalLabel: string;
  navItems: NavItem[];
  activeKey: string;
  onNavChange: (key: string) => void;
  onLogout: () => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
  userName?: string;
  children: ReactNode;
}

export function PortalShell({
  portalLabel,
  navItems,
  activeKey,
  onNavChange,
  onLogout,
  isMobileMenuOpen,
  setIsMobileMenuOpen,
  userName,
  children,
}: PortalShellProps) {
  const activeLabel = navItems.find((item) => item.key === activeKey)?.label ?? '';

  return (
    <div className="flex h-full w-full bg-brand-navy-base">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-brand-navy-border bg-brand-navy-surface transition-transform duration-200 lg:static lg:translate-x-0 ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between border-b border-brand-navy-border px-5 py-5">
          <div className="flex items-center gap-2.5">
            <Shield className="h-5 w-5 text-brand-gold" />
            <div>
              <p className="text-sm font-semibold text-slate-100">LexCorp Horizon</p>
              <p className="text-[11px] tracking-wide text-slate-500">{portalLabel}</p>
            </div>
          </div>
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="rounded-md p-1 text-slate-500 hover:text-slate-300 lg:hidden"
            aria-label="Close menu"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {navItems.map((item) => (
            <button
              key={item.key}
              onClick={() => {
                onNavChange(item.key);
                setIsMobileMenuOpen(false);
              }}
              className={`flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-sm transition ${
                activeKey === item.key
                  ? 'bg-brand-navy-elevated text-brand-gold'
                  : 'text-slate-400 hover:bg-brand-navy-elevated hover:text-slate-200'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        <div className="border-t border-brand-navy-border p-3">
          <button
            onClick={onLogout}
            className="flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-sm text-slate-400 transition hover:bg-brand-navy-elevated hover:text-red-400"
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </button>
        </div>
      </aside>

      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Main content */}
      <div className="flex h-screen min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-brand-navy-border bg-brand-navy-surface px-4 py-4 lg:px-8">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="rounded-md p-1.5 text-slate-400 hover:bg-brand-navy-elevated lg:hidden"
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" />
            </button>
            <h1 className="text-base font-semibold text-slate-100">{activeLabel}</h1>
          </div>
          {userName && (
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <span className="hidden sm:inline">{userName}</span>
              <div className="flex h-8 w-8 items-center justify-center rounded-full border border-brand-navy-border bg-brand-navy-elevated text-xs font-semibold text-brand-gold">
                {userName.slice(0, 1).toUpperCase()}
              </div>
            </div>
          )}
        </header>

        <main className="hide-scrollbar flex-1 overflow-y-auto p-4 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
