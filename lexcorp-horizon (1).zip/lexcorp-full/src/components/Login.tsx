import { useState, FormEvent } from 'react';
import { Shield, Mail, Lock, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useAppContext } from '../context/AppContext';

export function Login() {
  const { login } = useAppContext();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (!email.trim() || !password) {
      toast.error('Enter your email and password.');
      return;
    }

    setIsSubmitting(true);
    try {
      await login(email.trim(), password);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Sign-in failed. Check your credentials.';
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-brand-navy-base px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-full border border-brand-navy-border bg-brand-navy-surface">
            <Shield className="h-6 w-6 text-brand-gold" />
          </div>
          <div>
            <h1 className="gold-text text-xl font-semibold">LexCorp Horizon</h1>
            <p className="mt-1 text-sm text-slate-400">Compliance access for authorized personnel</p>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="space-y-4 rounded-lg border border-brand-navy-border bg-brand-navy-surface p-6"
        >
          <div>
            <label htmlFor="email" className="mb-1.5 block text-xs font-medium text-slate-400">
              Email
            </label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@firm.co.ke"
                className="w-full rounded-md border border-brand-navy-border bg-brand-navy-elevated py-2.5 pl-10 pr-3 text-sm text-slate-100 placeholder:text-slate-600 focus:border-brand-gold focus:outline-none focus:ring-1 focus:ring-brand-gold"
              />
            </div>
          </div>

          <div>
            <label htmlFor="password" className="mb-1.5 block text-xs font-medium text-slate-400">
              Password
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-md border border-brand-navy-border bg-brand-navy-elevated py-2.5 pl-10 pr-3 text-sm text-slate-100 placeholder:text-slate-600 focus:border-brand-gold focus:outline-none focus:ring-1 focus:ring-brand-gold"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="flex w-full items-center justify-center gap-2 rounded-md bg-brand-gold py-2.5 text-sm font-semibold text-brand-navy-base transition hover:bg-brand-gold-hover disabled:cursor-not-allowed disabled:opacity-60"
          >
            {isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
            {isSubmitting ? 'Verifying...' : 'Sign in'}
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-slate-600">
          Access is provisioned by your firm&apos;s administrator.
        </p>
      </div>
    </div>
  );
}
