import { useMemo, useState } from 'react';
import { LayoutDashboard, Scale, Users, ShieldAlert, FileWarning } from 'lucide-react';
import { PortalShell, NavItem } from '../layout/PortalShell';
import { ClientComplianceTable } from '../shared/ClientComplianceTable';
import { TeamRoster } from '../shared/TeamRoster';
import { StatCard } from '../shared/StatCard';
import { initialClients, initialTeam } from '../../data';
import { useAppContext } from '../../context/AppContext';

interface PortalProps {
  onLogout: () => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
}

const NAV_ITEMS: NavItem[] = [
  { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-4 w-4" /> },
  { key: 'clients', label: 'Client Registry', icon: <Scale className="h-4 w-4" /> },
  { key: 'team', label: 'Firm Team', icon: <Users className="h-4 w-4" /> },
];

export function AdvocatePortal({ onLogout, isMobileMenuOpen, setIsMobileMenuOpen }: PortalProps) {
  const [activeKey, setActiveKey] = useState('dashboard');
  const { user } = useAppContext();

  const atRisk = useMemo(
    () => initialClients.filter((c) => c.riskLevel !== 'COMPLIANT' && c.riskLevel !== 'Low'),
    []
  );
  const strikeOffRisk = useMemo(
    () => initialClients.filter((c) => c.riskLevel === 'STRIKE-OFF RISK (SEC 894)'),
    []
  );
  const pendingAudit = useMemo(() => initialClients.filter((c) => c.riskLevel === 'PENDING AUDIT'), []);

  return (
    <PortalShell
      portalLabel="Advocate Portal"
      navItems={NAV_ITEMS}
      activeKey={activeKey}
      onNavChange={setActiveKey}
      onLogout={onLogout}
      isMobileMenuOpen={isMobileMenuOpen}
      setIsMobileMenuOpen={setIsMobileMenuOpen}
      userName={user?.name}
    >
      {activeKey === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Entities under mandate" value={initialClients.length} icon={<Scale className="h-4 w-4" />} />
            <StatCard label="At risk" value={atRisk.length} icon={<ShieldAlert className="h-4 w-4" />} tone="warn" />
            <StatCard
              label="Strike-off risk"
              value={strikeOffRisk.length}
              icon={<FileWarning className="h-4 w-4" />}
              tone="danger"
            />
            <StatCard label="Pending audit" value={pendingAudit.length} icon={<ShieldAlert className="h-4 w-4" />} tone="warn" />
          </div>
          <ClientComplianceTable
            clients={initialClients}
            title="Client Compliance Overview"
            exportFileName="client-compliance-overview"
          />
        </div>
      )}

      {activeKey === 'clients' && (
        <ClientComplianceTable clients={initialClients} title="Client Registry" exportFileName="client-registry" />
      )}

      {activeKey === 'team' && <TeamRoster team={initialTeam} />}
    </PortalShell>
  );
}
