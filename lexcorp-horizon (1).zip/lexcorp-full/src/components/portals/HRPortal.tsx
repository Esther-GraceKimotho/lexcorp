import { useState } from 'react';
import { LayoutDashboard, Users, UserPlus, X } from 'lucide-react';
import { toast } from 'sonner';
import { PortalShell, NavItem } from '../layout/PortalShell';
import { TeamRoster } from '../shared/TeamRoster';
import { StatCard } from '../shared/StatCard';
import { initialTeam } from '../../data';
import { useAppContext } from '../../context/AppContext';
import type { TeamMember } from '../../types';

interface PortalProps {
  onLogout: () => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
}

const NAV_ITEMS: NavItem[] = [
  { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-4 w-4" /> },
  { key: 'team', label: 'Team Directory', icon: <Users className="h-4 w-4" /> },
];

const ROLE_OPTIONS: TeamMember['role'][] = ['Managing Partner', 'Associate', 'Clerk'];

export function HRPortal({ onLogout, isMobileMenuOpen, setIsMobileMenuOpen }: PortalProps) {
  const [activeKey, setActiveKey] = useState('dashboard');
  // NOTE: held in local state for now. To persist across sessions, wire this
  // up to a `team_members` table in Supabase (insert on add, select on load).
  const [team, setTeam] = useState<TeamMember[]>(initialTeam);
  const [showAddForm, setShowAddForm] = useState(false);
  const { user } = useAppContext();

  const handleAddMember = (member: Omit<TeamMember, 'id'>) => {
    setTeam((prev) => [...prev, { ...member, id: crypto.randomUUID() }]);
    setShowAddForm(false);
    toast.success(`${member.name} added to the roster.`);
  };

  return (
    <PortalShell
      portalLabel="HR Portal"
      navItems={NAV_ITEMS}
      activeKey={activeKey}
      onNavChange={setActiveKey}
      onLogout={onLogout}
      isMobileMenuOpen={isMobileMenuOpen}
      setIsMobileMenuOpen={setIsMobileMenuOpen}
      userName={user?.name}
    >
      {activeKey === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <StatCard label="Total staff" value={team.length} icon={<Users className="h-4 w-4" />} />
            <StatCard
              label="Partners"
              value={team.filter((m) => m.role === 'Managing Partner').length}
              icon={<Users className="h-4 w-4" />}
            />
            <StatCard
              label="Associates & clerks"
              value={team.filter((m) => m.role !== 'Managing Partner').length}
              icon={<Users className="h-4 w-4" />}
            />
          </div>
          <TeamRoster team={team} />
        </div>
      )}

      {activeKey === 'team' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-400">{team.length} staff on record</p>
            <button
              onClick={() => setShowAddForm(true)}
              className="flex items-center gap-2 rounded-md bg-brand-gold px-3 py-2 text-sm font-semibold text-brand-navy-base transition hover:bg-brand-gold-hover"
            >
              <UserPlus className="h-4 w-4" />
              Add member
            </button>
          </div>
          <TeamRoster team={team} />
        </div>
      )}

      {showAddForm && <AddMemberModal onClose={() => setShowAddForm(false)} onSubmit={handleAddMember} />}
    </PortalShell>
  );
}

function AddMemberModal({
  onClose,
  onSubmit,
}: {
  onClose: () => void;
  onSubmit: (member: Omit<TeamMember, 'id'>) => void;
}) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<TeamMember['role']>('Associate');

  const handleSubmit = () => {
    if (!name.trim() || !email.trim()) {
      toast.error('Name and email are required.');
      return;
    }
    onSubmit({ name: name.trim(), email: email.trim(), role });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4">
      <div className="w-full max-w-sm rounded-lg border border-brand-navy-border bg-brand-navy-surface p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-100">Add team member</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-300" aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="space-y-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Full name"
            className="w-full rounded-md border border-brand-navy-border bg-brand-navy-elevated px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:border-brand-gold focus:outline-none"
          />
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            className="w-full rounded-md border border-brand-navy-border bg-brand-navy-elevated px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:border-brand-gold focus:outline-none"
          />
          <select
            value={role}
            onChange={(e) => setRole(e.target.value as TeamMember['role'])}
            className="w-full rounded-md border border-brand-navy-border bg-brand-navy-elevated px-3 py-2 text-sm text-slate-100 focus:border-brand-gold focus:outline-none"
          >
            {ROLE_OPTIONS.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
          <button
            onClick={handleSubmit}
            className="w-full rounded-md bg-brand-gold py-2.5 text-sm font-semibold text-brand-navy-base transition hover:bg-brand-gold-hover"
          >
            Add to roster
          </button>
        </div>
      </div>
    </div>
  );
}
