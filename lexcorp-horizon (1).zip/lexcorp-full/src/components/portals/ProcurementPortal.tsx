import { useMemo, useState } from 'react';
import { LayoutDashboard, Boxes, ShieldCheck, ShieldX } from 'lucide-react';
import { PortalShell, NavItem } from '../layout/PortalShell';
import { ClientComplianceTable } from '../shared/ClientComplianceTable';
import { StatCard } from '../shared/StatCard';
import { initialClients } from '../../data';
import { useAppContext } from '../../context/AppContext';

interface PortalProps {
  onLogout: () => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
}

const NAV_ITEMS: NavItem[] = [
  { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-4 w-4" /> },
  { key: 'vendors', label: 'Vendor Compliance', icon: <Boxes className="h-4 w-4" /> },
];

export function ProcurementPortal({ onLogout, isMobileMenuOpen, setIsMobileMenuOpen }: PortalProps) {
  const [activeKey, setActiveKey] = useState('dashboard');
  const { user } = useAppContext();

  // Procurement's practical question: can we pay this vendor without
  // triggering a KRA / eTIMS compliance issue on our own filings?
  const eligibleForPayment = useMemo(
    () => initialClients.filter((c) => c.statusETIMS === 'Green' && c.statusKRA === 'Green'),
    []
  );
  const blocked = useMemo(
    () => initialClients.filter((c) => c.statusETIMS === 'Red' || c.statusKRA === 'Red'),
    []
  );

  return (
    <PortalShell
      portalLabel="Procurement Portal"
      navItems={NAV_ITEMS}
      activeKey={activeKey}
      onNavChange={setActiveKey}
      onLogout={onLogout}
      isMobileMenuOpen={isMobileMenuOpen}
      setIsMobileMenuOpen={setIsMobileMenuOpen}
      userName={user?.name}
    >
      {activeKey === 'dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <StatCard label="Registered vendors" value={initialClients.length} icon={<Boxes className="h-4 w-4" />} />
            <StatCard label="Cleared for payment" value={eligibleForPayment.length} icon={<ShieldCheck className="h-4 w-4" />} />
            <StatCard label="Payment blocked" value={blocked.length} icon={<ShieldX className="h-4 w-4" />} tone="danger" />
          </div>
          <ClientComplianceTable
            clients={initialClients}
            title="Vendor Payment Eligibility"
            exportFileName="vendor-payment-eligibility"
          />
        </div>
      )}

      {activeKey === 'vendors' && (
        <ClientComplianceTable clients={initialClients} title="Vendor Compliance" exportFileName="vendor-compliance" />
      )}
    </PortalShell>
  );
}
