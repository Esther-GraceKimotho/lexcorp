import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { toast } from 'sonner';
import { supabase } from '../supabaseClient';

export type Role = 'Advocate' | 'HR_Manager' | 'Ops_Procurement';

export interface AppUser {
  id: string;
  email: string;
  name: string;
}

interface AppContextValue {
  user: AppUser | null;
  role: Role | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

// NOTE: role is read from `user_metadata.role`, which must be set on the
// Supabase user (e.g. via an admin invite flow or a trigger on sign-up).
// If your project instead tracks role in a separate `profiles` table keyed
// by user id, replace `deriveRole` with a query against that table.
const VALID_ROLES: Role[] = ['Advocate', 'HR_Manager', 'Ops_Procurement'];

function deriveRole(session: Session | null): Role | null {
  if (!session?.user) return null;
  const metaRole = session.user.user_metadata?.role;
  if (VALID_ROLES.includes(metaRole)) return metaRole as Role;
  // No role on the account yet — fail closed rather than defaulting to a
  // portal, since these portals gate legal/financial/HR data.
  return null;
}

function deriveUser(session: Session | null): AppUser | null {
  if (!session?.user) return null;
  const { id, email, user_metadata } = session.user;
  return {
    id,
    email: email ?? '',
    name: (user_metadata?.full_name as string | undefined) ?? email?.split('@')[0] ?? 'User',
  };
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    supabase.auth.getSession().then(({ data }) => {
      if (!isMounted) return;
      setSession(data.session);
      setIsLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      setIsLoading(false);
    });

    return () => {
      isMounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  const login = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  };

  const logout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error('Could not sign out. Please try again.');
      throw error;
    }
  };

  const value: AppContextValue = {
    user: deriveUser(session),
    role: deriveRole(session),
    isLoading,
    login,
    logout,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used within an AppProvider');
  return ctx;
}
